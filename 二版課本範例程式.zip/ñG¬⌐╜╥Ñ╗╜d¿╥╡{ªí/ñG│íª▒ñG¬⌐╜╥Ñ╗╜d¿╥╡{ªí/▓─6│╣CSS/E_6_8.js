 function UnitsCompute() {
    var w = document.getElementById("sel").value;
	var amount = document.getElementById("amt").value;
	document.getElementById("result").innerHTML = amount/w; 
}
