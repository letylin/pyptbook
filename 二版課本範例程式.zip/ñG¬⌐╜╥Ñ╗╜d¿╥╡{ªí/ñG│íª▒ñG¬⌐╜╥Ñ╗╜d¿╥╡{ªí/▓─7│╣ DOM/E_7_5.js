function fontsizesetting() {
    	var fs = document.getElementById("fsize");
    	if (fs.style.fontSize == "16pt") {
            	fs.style.fontSize = "10pt";
    	}else {
            	fs.style.fontSize = "16pt";
    	}   	
}
function fontstylesetting() {
    	var fs = document.getElementById("fsize");
    	if (fs.style.fontStyle == "normal") {
            	fs.style.fontStyle = "italic";
    	}else {
            	fs.style.fontStyle = "normal";
    	}   	
}
function colorsetting() {
    	var fs = document.getElementById("fsize");
    	if (fs.style.color == "blue") {
            	fs.style.color = "red ";
    	}else {
            	fs.style.color = "blue";
    	}   	
}