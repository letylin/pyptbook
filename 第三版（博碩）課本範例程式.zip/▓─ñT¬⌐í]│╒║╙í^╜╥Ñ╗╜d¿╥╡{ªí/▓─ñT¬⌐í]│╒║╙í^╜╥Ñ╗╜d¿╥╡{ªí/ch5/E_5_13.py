# E_5_13 功能: range函數採先放大再縮小產生浮點數。
for i in range(0, 3):
    i=i/10
    print(i)
