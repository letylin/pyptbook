#E_5_4 功能: 迴圈依序印出序列的值
for i in range(0, 10, 2):
    print(i)
