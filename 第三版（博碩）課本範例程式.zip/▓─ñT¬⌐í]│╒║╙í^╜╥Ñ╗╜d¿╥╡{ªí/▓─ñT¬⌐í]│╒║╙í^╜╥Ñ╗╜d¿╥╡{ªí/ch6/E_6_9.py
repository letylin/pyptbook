#E_6_9.py 功能: 預設參數之後不能再有參數的範例
def showinf( name, age = 35, height):
   print('Name = ', name)
   print('Age = ', age)
showinf( name='Jeremy',age=50, height=180)

