#E_8_10\__init_.py
print('E_8_10\\__init__.py')