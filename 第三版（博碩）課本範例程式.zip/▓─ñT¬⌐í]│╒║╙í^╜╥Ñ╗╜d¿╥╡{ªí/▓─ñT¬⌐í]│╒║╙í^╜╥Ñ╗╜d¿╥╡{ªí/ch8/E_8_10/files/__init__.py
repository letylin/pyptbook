#E_8_10\files\__init_.py
print('E_8_10\\files\\__init__.py')