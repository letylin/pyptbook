#E_8_10\files\openfile.py
def openf():
    return('This is E_8_10\\files\\openfile.py') 