#E_8_10\formats\__init_.py
print('E_8_10\\formats\__init__.py')