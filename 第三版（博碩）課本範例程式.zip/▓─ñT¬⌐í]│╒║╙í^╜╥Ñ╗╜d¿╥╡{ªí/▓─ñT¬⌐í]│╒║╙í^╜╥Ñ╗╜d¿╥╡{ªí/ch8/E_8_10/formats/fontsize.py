#E_8_10\formats\fontsize.py
def size():
    return('This is E_8_10\\formats\\fontsize.py') 