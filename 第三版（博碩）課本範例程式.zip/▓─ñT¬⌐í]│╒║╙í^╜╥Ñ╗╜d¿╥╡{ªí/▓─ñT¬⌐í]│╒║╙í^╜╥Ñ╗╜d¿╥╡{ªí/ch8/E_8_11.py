#E_8_11: 呼叫套件的方法
import E_8_10.files.openfile as o
from E_8_10.formats import fontsize as s
print(o.openf())
print(o.__name__)
print(s.size())
print(s.__name__)